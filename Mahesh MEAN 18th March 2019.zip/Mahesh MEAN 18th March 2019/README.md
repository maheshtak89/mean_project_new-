# mean_project

This project is about managing Person's details with authentication and Autharization. For this project I have used Angular as a front End and Node fr server side. To store databse I have used mongoDB databse, and to interact with MongoDB I have used Express framework.

Note: Please run 'npm run install' from both source directories, to autoDownload dependancies. To run this project, please run 'npm run start' from both source directories.
