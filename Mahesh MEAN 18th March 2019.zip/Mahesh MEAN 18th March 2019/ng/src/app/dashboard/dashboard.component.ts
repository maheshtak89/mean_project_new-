import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  showdrop = false;
  showdrop1 = false;
  flag: string;
  roleName: string;
  userName: string;

  constructor() {
    this.flag = '';
   }


  ngOnInit() {
    this.roleName = sessionStorage.getItem('roleName');
    this.userName = sessionStorage.getItem('userName');
    console.log(this.roleName);
    if (this.roleName === 'Admin') {
        this.flag = 'allGrant';
    } else if (this.roleName === 'Operator') {
        this.flag = 'noGrant';
    }
  }

  showdropdown(): void {
    this.showdrop = !this.showdrop;
    this.showdrop1 = false;

  }
  showdropdown1(): void {
    this.showdrop1 = !this.showdrop1;
    this.showdrop = false;
  }

}
