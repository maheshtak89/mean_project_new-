export class Role {
  constructor(
    public roleId: number,
    public roleName: string
    ) {  }
}

export const roles: string[] = [];
